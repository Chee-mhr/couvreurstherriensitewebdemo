/* =========================================================================
   toit3d.js — coupe éclatée d'un toit plat (Three.js)
   Le modèle vit derrière le héros puis se démonte pendant la section
   « Anatomie ». Piloté depuis main.js via l'API exposée dans l'événement
   « toit3d:pret ».
   ========================================================================= */

import * as THREE from "three";

const hote = document.getElementById("scene");
if (hote) init();

function init() {
  const reduit = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const mobile = window.matchMedia("(max-width: 900px)").matches;

  /* ------------------------------------------------------------ moteur */
  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: "high-performance" });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, mobile ? 1.75 : 2));
  renderer.setSize(hote.clientWidth, hote.clientHeight);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;
  hote.appendChild(renderer.domElement);

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(32, hote.clientWidth / hote.clientHeight, 0.1, 100);
  camera.position.set(0, 1.9, 9.2);

  /* ------------------------------------------------------------ lumière */
  scene.add(new THREE.HemisphereLight(0xb9d4ea, 0x161b21, 1.05));

  const cle = new THREE.DirectionalLight(0xfff5ea, 2.2);
  cle.position.set(6, 9, 7);
  scene.add(cle);

  const remplissage = new THREE.DirectionalLight(0xa8c6e2, 0.8);
  remplissage.position.set(-7, 2, 6);
  scene.add(remplissage);

  // liseré cuivre à contre-jour — l'accent de la marque, jamais en pleine face
  const cuivre = new THREE.PointLight(0xd9772f, 30, 24, 2);
  cuivre.position.set(-3.6, 1.4, -4.2);
  scene.add(cuivre);

  const laiton = new THREE.PointLight(0xd9a441, 10, 16, 2);
  laiton.position.set(3.2, -2.2, 2.6);
  scene.add(laiton);

  /* ------------------------------------------------------------ modèle */
  const L = 3.9;   // largeur
  const P = 2.7;   // profondeur

  // de bas en haut — épaisseur (unités scène) et couleur
  const defs = [
    { e: 0.20, c: 0x4d5966, r: 0.85, m: 0.05 }, // pontage
    { e: 0.07, c: 0x1f3140, r: 0.55, m: 0.15 }, // pare-vapeur
    { e: 0.42, c: 0xcfc7b6, r: 0.95, m: 0.0  }, // isolant
    { e: 0.09, c: 0x2b3138, r: 0.6,  m: 0.1  }, // membrane de base
    { e: 0.11, c: 0x191c20, r: 0.75, m: 0.08 }, // membrane de finition
  ];

  const groupe = new THREE.Group();
  scene.add(groupe);

  const couches = [];
  let y = 0;
  defs.forEach((d, i) => {
    const sous = new THREE.Group();

    const mat = new THREE.MeshStandardMaterial({ color: d.c, roughness: d.r, metalness: d.m });
    const geo = new THREE.BoxGeometry(L, d.e, P);
    const dalle = new THREE.Mesh(geo, mat);
    sous.add(dalle);

    // arêtes fines — le trait de dessin d'architecte
    const aretes = new THREE.LineSegments(
      new THREE.EdgesGeometry(geo),
      new THREE.LineBasicMaterial({
        color: i === 4 ? 0xd9772f : 0xf2eee7,
        transparent: true,
        opacity: i === 4 ? 0.75 : 0.22,
      })
    );
    sous.add(aretes);

    sous.position.y = y + d.e / 2;
    couches.push({ groupe: sous, base: sous.position.y, def: d });
    groupe.add(sous);
    y += d.e + 0.012;
  });

  // gravier sur la couche de finition
  const gravier = creerGravier(couches[4].def.e / 2);
  couches[4].groupe.add(gravier);

  // drain encastré dans les deux couches du bas (détail de métier)
  const drain = new THREE.Mesh(
    new THREE.CylinderGeometry(0.17, 0.17, 0.5, 20),
    new THREE.MeshStandardMaterial({ color: 0x8a8f96, roughness: 0.45, metalness: 0.75 })
  );
  drain.position.set(-1.05, 0.15, 0.55);
  groupe.add(drain);

  groupe.position.y = -0.45;

  function creerGravier(dessus) {
    const n = mobile ? 260 : 520;
    const geo = new THREE.IcosahedronGeometry(0.045, 0);
    const mat = new THREE.MeshStandardMaterial({ color: 0xa9a094, roughness: 1, metalness: 0 });
    const inst = new THREE.InstancedMesh(geo, mat, n);
    const d = new THREE.Object3D();
    const teinte = new THREE.Color();
    for (let i = 0; i < n; i++) {
      d.position.set((Math.random() - 0.5) * (L - 0.12), dessus + Math.random() * 0.03, (Math.random() - 0.5) * (P - 0.12));
      d.rotation.set(Math.random() * 3.14, Math.random() * 3.14, Math.random() * 3.14);
      const s = 0.6 + Math.random() * 0.8;
      d.scale.set(s, s * 0.7, s);
      d.updateMatrix();
      inst.setMatrixAt(i, d.matrix);
      teinte.setHSL(0.09, 0.06 + Math.random() * 0.08, 0.36 + Math.random() * 0.22);
      inst.setColorAt(i, teinte);
    }
    inst.instanceMatrix.needsUpdate = true;
    return inst;
  }

  /* --------------------------------------------------------- étiquettes */
  const etiquettes = [...hote.querySelectorAll(".etiq")];
  const projete = new THREE.Vector3();
  // hauteur réelle d'une étiquette — mesurée au chargement et à chaque
  // redimensionnement, jamais dans la boucle de rendu (ce serait un calcul de
  // mise en page à 60 images par seconde)
  let hauteurEtiq = 0;
  const mesurerEtiquettes = () => {
    hauteurEtiq = etiquettes.reduce((m, el) => Math.max(m, el.offsetHeight), 0);
  };

  /* ------------------------------------------------------------- états */
  // pose 0 = héros (modèle à droite, vu de loin) · pose 1 = anatomie (centré)
  // recalculées à chaque redimensionnement : le cadrage n'est pas le même
  // sur un écran large et sur un téléphone.
  let poses;
  function calculerPoses() {
    const etroit = hote.clientWidth < 900;
    poses = [
      { camY: 2.15, camZ: 9.8, grX: etroit ? 0 : 2.05, grY: etroit ? 1.1 : 0.10, rotX: 0.32, rotY: -0.60, ech: etroit ? 0.6 : 0.78 },
      { camY: 1.30, camZ: 10.2, grX: etroit ? 0 : -0.95, grY: etroit ? 0.35 : -0.10, rotX: 0.19, rotY: -0.40, ech: etroit ? 0.6 : 0.86 },
    ];
  }
  calculerPoses();

  // Écartement vertical entre deux couches, en unités de scène. Il est
  // dimensionné par la HAUTEUR DU TEXTE, pas par l'esthétique : à l'écran,
  // deux couches voisines doivent être séparées de plus que la hauteur d'une
  // étiquette, sinon les textes se recouvrent. Toucher à la taille de police
  // des étiquettes oblige à revérifier cette valeur.
  const ECART = 0.82;

  let progression = 0;   // 0 → 1 : démontage
  let pose = 0;          // 0 → 1 : interpolation héros → anatomie
  let visible = false;
  let souris = { x: 0, y: 0 };
  let cible = { x: 0, y: 0 };

  if (!reduit && !mobile) {
    window.addEventListener("pointermove", (e) => {
      cible.x = (e.clientX / window.innerWidth - 0.5) * 2;
      cible.y = (e.clientY / window.innerHeight - 0.5) * 2;
    }, { passive: true });
  }

  const doux = (t) => 1 - Math.pow(1 - t, 3);
  const borne = (v, a, b) => Math.min(b, Math.max(a, v));
  const melange = (a, b, t) => a + (b - a) * t;

  function appliquer(temps) {
    const p = poses[0], q = poses[1];
    const t = pose;

    camera.position.y = melange(p.camY, q.camY, t);
    camera.position.z = melange(p.camZ, q.camZ, t);
    camera.lookAt(0, 0.1, 0);

    const ech = melange(p.ech, q.ech, t);
    groupe.scale.setScalar(ech);
    groupe.position.x = melange(p.grX, q.grX, t);
    // Les couches ne montent que vers le haut : sans compensation, la pile
    // dérive hors du cadre et l'étiquette du dessus passe sous l'entête.
    // On redescend le groupe de la moitié de la hauteur gagnée pour que la
    // coupe éclatée reste centrée.
    const derive = doux(borne(progression, 0, 1)) * (4 * ECART) * 0.46;
    groupe.position.y = melange(p.grY, q.grY, t) - 0.3 - derive * ech;

    // dérive lente + parallaxe souris
    souris.x += (cible.x - souris.x) * 0.045;
    souris.y += (cible.y - souris.y) * 0.045;
    const flotte = reduit ? 0 : Math.sin(temps * 0.00025) * 0.09;

    groupe.rotation.x = melange(p.rotX, q.rotX, t) + souris.y * 0.06;
    groupe.rotation.y = melange(p.rotY, q.rotY, t) + flotte + souris.x * 0.14;

    // démontage étagé : la couche du haut part la première
    couches.forEach((c, i) => {
      const depart = (4 - i) * 0.1;
      const ti = doux(borne((progression - depart) / 0.42, 0, 1));
      c.groupe.position.y = c.base + ti * (i * ECART + 0.06);
      c.groupe.position.x = ti * i * 0.055;
    });
    drain.position.y = 0.15 - progression * 0.35;
    drain.visible = progression < 0.55;

    // Étiquettes projetées, en deux passes : on projette d'abord toutes les
    // couches, puis on décide de l'opacité de chacune en connaissant ses
    // voisines. Une étiquette reste ancrée à SA couche — on ne la déplace
    // jamais pour éviter un chevauchement, on la révèle seulement quand la
    // place existe réellement. Le texte ne se superpose donc jamais.
    const largeur = hote.clientWidth, hauteur = hote.clientHeight;
    const places = couches.map((c) => {
      projete.set(L / 2 - 0.2, 0, 0).applyMatrix4(c.groupe.matrixWorld).project(camera);
      return {
        x: borne((projete.x * 0.5 + 0.5) * largeur, 12, largeur - 320),
        y: (-projete.y * 0.5 + 0.5) * hauteur,
      };
    });

    etiquettes.forEach((el, i) => {
      const p = places[i];
      const h = hauteurEtiq || 96;

      // 1. la couche a commencé à se détacher
      // La coupe est pleinement ouverte à progression = 1 : c'est là qu'on
      // veut lire les noms, donc aucune extinction à ce moment. C'est le
      // fondu de la scène entière, plus loin dans le défilement, qui les
      // emporte.
      let op = borne((progression - (0.2 + (4 - i) * 0.09)) / 0.14, 0, 1);

      // 2. il y a assez d'écart avec la couche voisine pour lire le texte
      const voisines = [places[i - 1], places[i + 1]].filter(Boolean);
      if (voisines.length) {
        const ecart = Math.min(...voisines.map((v) => Math.abs(v.y - p.y)));
        op *= borne((ecart - h * 0.88) / (h * 0.35), 0, 1);
      }

      // 3. l'étiquette tient dans la fenêtre, sous l'entête et au-dessus du bas
      op *= borne((p.y - 88) / 44, 0, 1) * borne((hauteur - 30 - p.y - h * 0.5) / 44, 0, 1);

      el.style.transform = `translate3d(${p.x.toFixed(1)}px, ${(p.y - 26).toFixed(1)}px, 0)`;
      el.style.opacity = op.toFixed(3);
    });
  }

  /* ------------------------------------------------------------- boucle */
  let brut = 0;
  function boucle(temps) {
    brut = requestAnimationFrame(boucle);
    if (!visible) return;
    appliquer(temps);
    renderer.render(scene, camera);
  }

  function redimensionner() {
    const w = hote.clientWidth, h = hote.clientHeight;
    calculerPoses();
    mesurerEtiquettes();
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    renderer.setSize(w, h);
    groupe.updateMatrixWorld(true);
    appliquer(performance.now());
    renderer.render(scene, camera);
  }
  window.addEventListener("resize", redimensionner);

  mesurerEtiquettes();
  // les polices arrivent après le premier rendu et changent la hauteur du texte
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(mesurerEtiquettes);

  groupe.updateMatrixWorld(true);

  /* ---------------------------------------------------------------- API */
  const api = {
    /** avancement du démontage, 0 → 1 */
    demonter(v) { progression = borne(v, 0, 1); },
    /** interpolation de la pose héros (0) vers la pose anatomie (1) */
    poser(v) { pose = borne(v, 0, 1); },
    /** coupe la boucle de rendu quand la scène est hors écran */
    afficher(v) { visible = !!v; },
    /** force une image immédiate — la boucle rAF est gelée dans un onglet
     *  d'arrière-plan, donc positions et étiquettes doivent pouvoir être
     *  recalculées à la demande (reprise d'onglet, mesure, capture) */
    rendre() {
      groupe.updateMatrixWorld(true);
      appliquer(performance.now());
      renderer.render(scene, camera);
    },
    couches: defs.length,
    reduit,
  };

  if (reduit) {
    // mouvement réduit : une seule image, coupe déjà ouverte
    visible = true;
    progression = 0.62;
    pose = 1;
    groupe.updateMatrixWorld(true);
    appliquer(0);
    renderer.render(scene, camera);
    api.demonter = api.poser = () => {};
  } else {
    brut = requestAnimationFrame(boucle);
  }

  window.Toit3D = api;
  window.dispatchEvent(new CustomEvent("toit3d:pret", { detail: api }));
}
