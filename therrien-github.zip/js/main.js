/* =========================================================================
   main.js — défilement fluide, chorégraphie GSAP, interface
   ========================================================================= */
(function () {
  "use strict";

  gsap.registerPlugin(ScrollTrigger, SplitText);

  const reduit = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const $ = (s, c) => (c || document).querySelector(s);
  const $$ = (s, c) => [...(c || document).querySelectorAll(s)];

  // sur petit écran la coupe 3D passe derrière le texte, en retrait
  const opScene = window.innerWidth < 900 ? 0.55 : 1;

  /* ------------------------------------------------- photo d'ouverture */
  // Le gestionnaire d'erreur est ici et non en attribut `onerror` : la CSP
  // du site interdit les gestionnaires en ligne. On essaie les extensions
  // courantes, puis on retire la couche — sans photo, le héros reprend
  // exactement son apparence d'origine, jamais une image cassée.
  (function photoOuverture() {
    const couche = document.getElementById("fond-photo");
    const img = couche && couche.querySelector("img");
    if (!img) return;

    const candidats = ["photos/couvreur.jpg", "photos/couvreur.jpeg", "photos/couvreur.png", "photos/couvreur.webp"];
    let i = 0;
    let fini = false;

    const suivante = () => {
      if (fini) return;
      i += 1;
      if (i < candidats.length) {
        img.src = candidats[i];
        surveiller();
      } else {
        fini = true;
        couche.remove();
      }
    };

    function surveiller() {
      // decode() tranche sans ambiguïté : il ne se résout qu'une fois l'image
      // réellement décodable et rejette si le chargement a échoué — y compris
      // s'il a échoué AVANT l'exécution de ce script.
      // Ne PAS revenir au couple `complete && naturalWidth === 0` : `complete`
      // vaut déjà true sur une image dont la requête n'est que mise en file
      // d'attente (onglet en arrière-plan, réseau lent), ce qui retirait la
      // photo alors qu'elle se chargeait normalement.
      if (typeof img.decode === "function") {
        img.decode().then(() => { fini = true; }).catch(suivante);
      } else {
        img.addEventListener("error", suivante, { once: true });
      }
    }
    surveiller();
  })();

  /* --------------------------------------------------- défilement fluide */
  let lenis = null;
  if (!reduit) {
    lenis = new Lenis({ lerp: 0.09, smoothWheel: true, wheelMultiplier: 1 });
    lenis.on("scroll", ScrollTrigger.update);
    gsap.ticker.add((t) => lenis.raf(t * 1000));
    gsap.ticker.lagSmoothing(0);
    window.__lenis = lenis; // pratique pour piloter la page en test
  }

  const allerA = (cible) => {
    if (lenis) lenis.scrollTo(cible, { offset: -10, duration: 1.3 });
    else document.querySelector(cible)?.scrollIntoView();
  };

  $$('a[href^="#"]').forEach((a) => {
    a.addEventListener("click", (e) => {
      const id = a.getAttribute("href");
      if (id.length < 2 || !document.querySelector(id)) return;
      e.preventDefault();
      fermerMenu();
      allerA(id);
    });
  });

  /* ------------------------------------------------------ barre + entête */
  const entete = $("#entete");
  const progres = $("#progres");

  // L'entête passe en encre foncée au-dessus des sections claires.
  // Calculé sans état à chaque image à partir de la géométrie réelle : une
  // bascule par déclencheur laissait l'entête coincée dans le mauvais mode
  // après un saut de défilement, l'ordre de déclenchement décidant du résultat.
  const zonesClaires = $$(".section:not(.inv)");
  // « dark » est accepté en plus de « nuit » : certains hôtes de page (visionneuse
  // d'artefact, extensions) imposent eux-mêmes data-theme="dark" sur la racine.
  const estNuit = () => /nuit|dark/.test(document.documentElement.dataset.theme || "");
  const majEntete = () => {
    const surClair =
      !estNuit() &&
      zonesClaires.some((s) => {
        const r = s.getBoundingClientRect();
        return r.top <= 62 && r.bottom >= 62;
      });
    entete.classList.toggle("sur-clair", surClair);
  };

  ScrollTrigger.create({
    start: 0,
    end: "max",
    onUpdate: (self) => {
      gsap.set(progres, { scaleX: self.progress });
      entete.classList.toggle("collee", self.scroll() > 40);
      majEntete();
    },
  });
  majEntete();

  /* ------------------------------------------------------------ thème */
  const racine = document.documentElement;
  const prefNuit = window.matchMedia("(prefers-color-scheme: dark)").matches;
  racine.dataset.theme =
    localStorage.getItem("therrien-theme") || (estNuit() || prefNuit ? "nuit" : "jour");

  $("#bascule").addEventListener("click", () => {
    const suivant = estNuit() ? "jour" : "nuit";
    racine.dataset.theme = suivant;
    localStorage.setItem("therrien-theme", suivant);
    majEntete();
    ScrollTrigger.refresh();
  });

  /* -------------------------------------------------------- menu mobile */
  const menu = $("#menu");
  const burger = $("#burger");
  let tlMenu = gsap.timeline({ paused: true })
    .to(menu, { clipPath: "inset(0% 0% 0% 0%)", duration: 0.75, ease: "power4.inOut" })
    .from(menu.querySelectorAll("a"), { yPercent: 110, opacity: 0, duration: 0.6, stagger: 0.06, ease: "power3.out" }, "-=0.35");

  function ouvrirMenu() {
    menu.classList.add("ouvert");
    menu.removeAttribute("inert"); // fermé, le menu ne doit pas capter le focus
    burger.setAttribute("aria-expanded", "true");
    lenis && lenis.stop();
    tlMenu.play();
  }
  function fermerMenu() {
    if (!menu.classList.contains("ouvert")) return;
    menu.classList.remove("ouvert");
    menu.setAttribute("inert", "");
    burger.setAttribute("aria-expanded", "false");
    lenis && lenis.start();
    tlMenu.reverse();
  }
  burger.addEventListener("click", ouvrirMenu);
  $("#fermer-menu").addEventListener("click", fermerMenu);
  window.addEventListener("keydown", (e) => e.key === "Escape" && fermerMenu());

  /* ------------------------------------------------------ entrée du héros */
  document.fonts.ready.then(() => {
    const split = new SplitText("#titre-heros", { type: "lines", mask: "lines" });
    const tl = gsap.timeline({ defaults: { ease: "power4.out" } });
    tl.from(split.lines, { yPercent: 115, duration: 1.15, stagger: 0.085 })
      .from('[data-heros="sub"]', { y: 26, opacity: 0, duration: 0.9, stagger: 0.1 }, "-=0.65")
      .from('[data-heros="cta"]', { y: 26, opacity: 0, duration: 0.9, stagger: 0.1 }, "-=0.7")
      .from("#entete", { yPercent: -110, opacity: 0, duration: 0.9 }, "-=0.9");
    ScrollTrigger.refresh();
  });

  // Le fondu d'entrée de la scène 3D ne dépend PAS du chargement des polices :
  // si document.fonts.ready traîne, la coupe doit apparaître quand même.
  gsap.to("#scene", { opacity: opScene, duration: 1.4, ease: "power2.out", delay: 0.2 });

  /* --------------------------------------------------- révélations douces */
  $$("[data-reveal]").forEach((el) => {
    gsap.from(el, {
      y: 56, opacity: 0, duration: 1, ease: "power3.out",
      scrollTrigger: { trigger: el, start: "top 85%" },
    });
  });
  $$("[data-reveal-group]").forEach((g) => {
    gsap.from(g.children, {
      y: 48, opacity: 0, duration: 0.95, stagger: 0.08, ease: "power3.out",
      scrollTrigger: { trigger: g, start: "top 82%" },
    });
  });

  /* ------------------------------------------------------------ marquise */
  const piste = $("#marquise");
  if (piste) {
    // duplication par clonage de nœuds plutôt que par innerHTML : rien n'est
    // ré-analysé comme du HTML, donc aucune surface d'injection même si le
    // contenu de la marquise devient un jour dynamique
    [...piste.children].forEach((n) => piste.appendChild(n.cloneNode(true)));
    const tlM = gsap.to(piste, { xPercent: -50, duration: 34, ease: "none", repeat: -1 });
    ScrollTrigger.create({
      start: 0, end: "max",
      onUpdate: (self) => { tlM.timeScale(self.direction === 1 ? 1 : -1); },
    });
  }

  /* ------------------------------------------------------------ compteurs */
  $$("[data-count]").forEach((el) => {
    const fin = +el.dataset.count;
    gsap.fromTo(el, { textContent: 0 }, {
      textContent: fin, duration: 1.7, ease: "power2.out", snap: { textContent: 1 },
      scrollTrigger: { trigger: el, start: "top 88%" },
    });
  });

  /* ---------------------------------------------- basculement des cartes */
  if (!reduit && window.matchMedia("(hover:hover)").matches) {
    $$(".carte").forEach((carte) => {
      const rx = gsap.quickTo(carte, "rotationX", { duration: 0.6, ease: "power3.out" });
      const ry = gsap.quickTo(carte, "rotationY", { duration: 0.6, ease: "power3.out" });
      carte.addEventListener("pointermove", (e) => {
        const r = carte.getBoundingClientRect();
        rx(((e.clientY - r.top) / r.height - 0.5) * -7);
        ry(((e.clientX - r.left) / r.width - 0.5) * 9);
      });
      carte.addEventListener("pointerleave", () => { rx(0); ry(0); });
    });
  }

  /* ------------------------------------------------- anatomie + scène 3D */
  const numCouche = $("#num-couche");
  const nomCouche = $("#nom-couche");
  const noms = $$(".etiq .etiq__nom").map((n) => n.textContent.trim());
  const seuil = (i) => 0.2 + (4 - i) * 0.09;

  function majCompteur(p) {
    let actif = 4;
    for (let i = 0; i <= 4; i++) if (p > seuil(i)) { actif = i; break; }
    const num = String(actif + 1).padStart(2, "0");
    if (numCouche.textContent !== num) {
      numCouche.textContent = num;
      nomCouche.textContent = noms[actif] || "";
      gsap.fromTo([numCouche, nomCouche], { opacity: 0.2, y: 8 }, { opacity: 1, y: 0, duration: 0.45, ease: "power2.out" });
    }
  }
  majCompteur(0);

  function brancher3D(api) {
    // héros → anatomie : déplacement de la caméra
    ScrollTrigger.create({
      trigger: "#heros",
      start: "top top",
      end: "bottom top",
      scrub: true,
      onUpdate: (self) => api.poser(self.progress),
    });

    // La photo d'ouverture se dissout sur le même parcours, mais plus vite :
    // elle a totalement disparu aux deux tiers du héros, donc bien avant que
    // la coupe ne commence à se démonter. Léger recul d'échelle pour que la
    // disparition soit un mouvement, pas un simple fondu.
    const photo = $("#fond-photo");
    if (photo) {
      gsap.to(photo, {
        opacity: 0,
        scale: 1.08,
        ease: "none",
        scrollTrigger: { trigger: "#heros", start: "top top", end: "62% top", scrub: true },
      });
    }

    // section épinglée : démontage couche par couche
    ScrollTrigger.create({
      trigger: "#anatomie-ecran",
      start: "top top",
      end: "+=260%",
      pin: true,
      scrub: 1,
      anticipatePin: 1,
      onUpdate: (self) => {
        api.demonter(self.progress);
        majCompteur(self.progress);
      },
    });

    // rendu coupé dès que la scène quitte l'écran
    ScrollTrigger.create({
      trigger: "#anatomie",
      start: "top bottom",
      endTrigger: "#anatomie",
      end: "bottom top",
      onToggle: (self) => api.afficher(self.isActive),
    });
    ScrollTrigger.create({
      trigger: "#heros",
      start: "top bottom",
      end: "bottom top",
      onToggle: (self) => self.isActive && api.afficher(true),
    });
    api.afficher(true);

    // La scène s'efface quand l'anatomie est terminée.
    // fromTo + immediateRender:false est obligatoire ici : un `gsap.to` scrubbé
    // fige sa valeur de départ à la création (l'opacité valait encore 0) et
    // écraserait ensuite le fondu d'entrée du héros.
    const sortie = { start: "bottom 80%", end: "bottom 40%", scrub: true, trigger: "#anatomie" };
    gsap.fromTo("#scene", { opacity: opScene }, { opacity: 0, ease: "none", immediateRender: false, scrollTrigger: sortie });
    gsap.fromTo("#fond-nuit", { opacity: 1 }, { opacity: 0, ease: "none", immediateRender: false, scrollTrigger: { ...sortie } });

    ScrollTrigger.refresh();
  }

  if (window.Toit3D) brancher3D(window.Toit3D);
  else window.addEventListener("toit3d:pret", (e) => brancher3D(e.detail));

  /* ---------------------------------------------------------- formulaire */
  $$(".puce").forEach((p) => {
    p.addEventListener("click", () => {
      const groupe = p.closest(".puces");
      const multi = groupe.getAttribute("aria-labelledby") === "lbl-travaux";
      if (!multi) $$(".puce", groupe).forEach((a) => a !== p && a.setAttribute("aria-pressed", "false"));
      p.setAttribute("aria-pressed", p.getAttribute("aria-pressed") === "true" ? "false" : "true");
    });
  });

  const form = $("#form-soumission");
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const nom = $("#nom");
    const tel = $("#tel");
    if (!nom.value.trim() || !tel.value.trim()) {
      gsap.fromTo(!nom.value.trim() ? nom : tel, { x: -7 }, { x: 0, duration: 0.5, ease: "elastic.out(1,0.35)" });
      (!nom.value.trim() ? nom : tel).focus();
      return;
    }
    // Prototype : aucune requête réseau. Brancher ici l'envoi vers le
    // courriel de l'entreprise (Formspree, Netlify Forms, ou un POST maison).
    $("#merci-nom").textContent = nom.value.trim().split(/\s+/)[0];
    const merci = $("#merci");
    gsap.to(form, {
      opacity: 0, y: -14, duration: 0.45, ease: "power2.in",
      onComplete: () => {
        form.style.display = "none";
        merci.classList.add("ouvert");
        gsap.from(merci, { opacity: 0, y: 22, duration: 0.7, ease: "power3.out" });
        ScrollTrigger.refresh();
      },
    });
  });

  /* -------------------------------------------------------------- divers */
  $("#annee").textContent = new Date().getFullYear();

  window.addEventListener("load", () => ScrollTrigger.refresh());

  /* ------------------------------------------------------ mouvement réduit */
  if (reduit) {
    gsap.globalTimeline.timeScale(80);
    $$("[data-reveal], [data-reveal-group] > *, [data-heros]").forEach((el) =>
      gsap.set(el, { clearProps: "all", opacity: 1, y: 0 })
    );
    gsap.set("#scene", { opacity: 1 });
  }
})();
